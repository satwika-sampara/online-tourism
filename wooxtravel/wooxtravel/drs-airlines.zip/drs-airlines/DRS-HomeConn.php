<!DOCTYPE html>
<html>
<head>
    <title>DRS Airways - Flights</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Pacifico|Paytone+One" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="DRs-HomeConnCSSn.css">
</head>
<body>
    <!-- NavBar -->
    <nav class="navbar navbar-inverse">
        <!-- ... (your navigation bar) -->
    </nav>
    <!-- NavBar End -->

    <!-- SignUp Modal -->
    <!-- ... (your signup modal) -->
    <!-- SignUp Modal End -->

    <!-- Login Modal -->
    <!-- ... (your login modal) -->
    <!-- Login Modal End -->

    <div class="container">
        <!-- Add a form for user input -->
        <form method="POST" action="">
            <label for="origin">Origin:</label>
            <input type="text" name="origin" id="origin">
            <!-- Add other input fields as needed (destination, depart, return, passengers) -->
            <input type="submit" name="submit" value="Submit">
        </form>

        <h1 class="hsty" id="he1">Departure</h1>
        <table id="t1" width="600" border="2" cellpadding="5" cellspacing="5">
            <thead>
                <tr>
                    <th>Flight Number</th>
                    <th>Type</th>
                    <th>Origin</th>
                    <th>Destination</th>
                    <th>Departure Time</th>
                    <th>Arrival Time</th>
                    <th>Book</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    if (isset($_POST['submit'])) {
                        // Your PHP code for displaying departure table
                        // Adjust the database connection and query accordingly
                        $dbhost = "localhost";
                        $dbuser = "root";
                        $dbpass = "";
                        $db = "your_database_name";
                        $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $db);

                        if (!$conn) {
                            die("Connection failed: " . mysqli_connect_error());
                        }

                        $origin = mysqli_real_escape_string($conn, $_POST['origin']);

                        $sql = "SELECT * FROM flights WHERE origin = '$origin'";
                        $result = mysqli_query($conn, $sql);

                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>" . $row['flight_number'] . "</td>";
                            // Add other columns as needed
                            echo "<td>" . $row['type'] . "</td>";
                            echo "<td>" . $row['origin'] . "</td>";
                            echo "<td>" . $row['destination'] . "</td>";
                            echo "<td>" . $row['departure_time'] . "</td>";
                            echo "<td>" . $row['arrival_time'] . "</td>";
                            echo "<td><button>Book</button></td>";
                            echo "</tr>";
                        }

                        mysqli_close($conn);
                    }
                ?>
            </tbody>
        </table>

        <h1 class="hsty">Arrival</h1>
        <table id="t2" width="600" border="1" cellpadding="1" cellspacing="1">
            <thead>
                <tr>
                    <th>Flight Number</th>
                    <th>Type</th>
                    <th>Origin</th>
                    <th>Destination</th>
                    <th>Departure Time</th>
                    <th>Arrival Time</th>
                    <th>Book</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    if (isset($_POST['submit'])) {
                        // Your PHP code for displaying arrival table
                        // Adjust the database connection and query accordingly
                        $dbhost = "localhost";
                        $dbuser = "root";
                        $dbpass = "";
                        $db = "your_database_name";
                        $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $db);

                        if (!$conn) {
                            die("Connection failed: " . mysqli_connect_error());
                        }

                        $origin = mysqli_real_escape_string($conn, $_POST['origin']);

                        $sql = "SELECT * FROM flights WHERE destination = '$origin'";
                        $result = mysqli_query($conn, $sql);

                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>" . $row['flight_number'] . "</td>";
                            // Add other columns as needed
                            echo "<td>" . $row['type'] . "</td>";
                            echo "<td>" . $row['origin'] . "</td>";
                            echo "<td>" . $row['destination'] . "</td>";
                            echo "<td>" . $row['departure_time'] . "</td>";
                            echo "<td>" . $row['arrival_time'] . "</td>";
                            echo "<td><button>Book</button></td>";
                            echo "</tr>";
                        }

                        mysqli_close($conn);
                    }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
